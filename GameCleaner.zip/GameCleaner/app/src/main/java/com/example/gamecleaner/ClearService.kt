package com.example.gamecleaner

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView

class ClearService : AccessibilityService() {
    companion object {
        var inst: ClearService? = null
        const val PG = "com.google.android.play.games"
        val STORAGE = listOf("Storage", "التخزين", "ذخیرەسازی", "Depolama")
        val CLEAR = listOf("Clear data", "Clear storage", "محو البيانات", "مسح البيانات", "محو مساحة التخزين", "داتا بسڕە", "Verileri temizle")
        val SETTINGS = listOf("Settings", "الإعدادات", "ڕێکخستن", "Ayarlar")
        val DELACCT = listOf("Delete Play Games account", "Delete account", "حذف حساب Play Games", "حذف الحساب", "Play Games hesabını sil")
        val DELCONF = listOf("Delete", "حذف", "Next", "التالي", "Continue", "متابعة", "OK", "حسنًا", "Sil")
        val YOURDATA = listOf("Your data", "Activity and data management")
        val DELDATA = listOf("Delete Play Games data")
        val PERMDEL = listOf("Permanently delete")
        val PERM = listOf("Allow", "While using the app", "السماح", "أثناء استخدام التطبيق", "ڕێپێدان")
        val CONT = listOf("Continue as", "Continue", "Allow", "Accept", "متابعة", "السماح", "موافق", "بەردەوام بە")
        val GOOGLE = listOf("Sign in with Google", "Google", "Gmail", "تسجيل الدخول باستخدام Google", "تسجيل الدخول بحساب Google", "گووگڵ")
        val CONFIRM = listOf("OK", "Delete", "حسنًا", "حسنا", "موافق", "حذف", "باشە", "Tamam", "Sil")
    }

    var active = false
    private val h = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<String>()
    private var state = 0
    private var last = 0L
    private var all = listOf<String>()
    private var loop = false
    private var cycleStart = 0L
    private var email = ""
    private var tapX = 0f
    private var tapY = 0f
    private var clickedGoogle = false
    private var delAcct = false
    private var overlay: TextView? = null

    override fun onServiceConnected() { inst = this; showOverlay() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        stop(); removeOverlay(); inst = null
        return super.onUnbind(i)
    }

    // ---------- floating ON/OFF button ----------
    private fun showOverlay() {
        if (overlay != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(44, 28, 44, 28)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 320 }
        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false
        t.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(t, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (active) stop() else begin(true) }
            }
            true
        }
        wm.addView(t, lp); overlay = t; paint()
    }

    private fun removeOverlay() {
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        overlay = null
    }

    private fun paint() {
        overlay?.let {
            it.text = if (active) "⏸ ON" else "▶ OFF"
            it.background = GradientDrawable().apply {
                cornerRadius = 80f
                setColor(if (active) 0xFF1B8E3E.toInt() else 0xFFC62828.toInt())
            }
        }
    }

    // ---------- control ----------
    fun begin(repeat: Boolean) {
        val p = getSharedPreferences("p", MODE_PRIVATE)
        val xy = (p.getString("xy", "") ?: "").split(",").mapNotNull { it.trim().toFloatOrNull() }
        h.removeCallbacksAndMessages(null)
        all = (p.getString("list", "") ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }
        loop = repeat
        email = (p.getString("mail", "") ?: "").trim()
        tapX = xy.getOrElse(0) { 0f }; tapY = xy.getOrElse(1) { 0f }
        delAcct = p.getBoolean("cb", false)
        active = true; paint()
        performGlobalAction(GLOBAL_ACTION_HOME)
        h.postDelayed({ cycle() }, 1000)
    }

    fun stop() {
        loop = false; state = 0; active = false
        h.removeCallbacksAndMessages(null); paint()
    }

    private fun cycle() {
        cycleStart = System.currentTimeMillis()
        queue.clear(); queue.addAll(all)
        if (delAcct) beginAcct() else next()
    }

    private fun beginAcct() {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/games/profile"))
            .setPackage("com.android.chrome").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Exception) { next(); return }
        state = 20; last = System.currentTimeMillis()
        h.postDelayed({ acct() }, 4000)
    }

    // Chrome flow (as in the video): Your data -> Delete Play Games data -> Permanently delete
    // -> confirm -> OK -> Create a gamer name -> Create
    private fun acct() {
        if (state < 20) return
        val now = System.currentTimeMillis()
        if (now - last > 20000) { next(); return }
        val r = rootInActiveWindow
        if (r != null) {
            when (state) {
                20 -> if (click(r, YOURDATA)) { state = 21; last = now }
                21 -> if (click(r, DELDATA)) { state = 22; last = now }
                22 -> if (click(r, PERMDEL)) { state = 23; last = now }
                23 -> if (now - last > 1500 && clickLast(r, PERMDEL)) { state = 24; last = now }
                24 -> if (clickExact(r, "OK")) { state = 25; last = now }
                25 -> if (clickExact(r, "Create")) { state = 26; last = now }
                26 -> if (now - last > 3000) { next(); return }
            }
        }
        h.postDelayed({ acct() }, 800)
    }

    private fun clickLast(root: AccessibilityNodeInfo, words: List<String>): Boolean {
        for (w in words) for (n in root.findAccessibilityNodeInfosByText(w).reversed()) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun clickExact(root: AccessibilityNodeInfo, w: String): Boolean {
        for (n in root.findAccessibilityNodeInfosByText(w)) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!w.equals(t, true)) continue
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun next() {
        if (queue.isEmpty()) {
            state = 0
            if (!loop) { active = false; paint(); performGlobalAction(GLOBAL_ACTION_HOME); return }
            val game = all.firstOrNull()
            val li = game?.let { packageManager.getLaunchIntentForPackage(it) }
            if (li != null) startActivity(li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            clickedGoogle = false
            h.postDelayed({ login(0) }, 8000)
            val wait = maxOf(3000L, 60000L - (System.currentTimeMillis() - cycleStart))
            h.postDelayed({ if (loop) cycle() }, wait)
            return
        }
        val p = queue.removeFirst()
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = 1; last = System.currentTimeMillis()
        h.postDelayed({ tick() }, 1500)
    }

    private fun tick() {
        if (state == 0) return
        if (System.currentTimeMillis() - last > 12000) { next(); return }
        val r = rootInActiveWindow
        if (r != null) {
            when (state) {
                1, 2 -> {
                    if (click(r, CLEAR)) { state = 3; last = System.currentTimeMillis() }
                    else if (state == 1 && click(r, STORAGE)) { state = 2; last = System.currentTimeMillis() }
                }
                3 -> if (click(r, CONFIRM)) { state = 4; h.postDelayed({ next() }, 1200); return }
            }
        }
        h.postDelayed({ tick() }, 800)
    }

    private fun login(n: Int) {
        if (!loop || n > 40) return
        val r = rootInActiveWindow
        if (r != null) {
            if (click(r, PERM)) {
            } else if (email.isNotEmpty() && click(r, listOf(email))) {
                clickedGoogle = true
            } else if (clickedGoogle && click(r, CONT)) {
            } else if (!clickedGoogle) {
                click(r, GOOGLE)
            }
        }
        if (!clickedGoogle && tapX > 0f && n > 0 && n % 8 == 0) {
            val path = Path().apply { moveTo(tapX, tapY) }
            dispatchGesture(GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build(), null, null)
        }
        h.postDelayed({ login(n + 1) }, 2000)
    }

    private fun click(root: AccessibilityNodeInfo, words: List<String>): Boolean {
        for (w in words) for (n in root.findAccessibilityNodeInfosByText(w)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }
}
